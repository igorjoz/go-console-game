#pragma once


#ifndef HELPER_H
#define HELPER_H


class Helper
{
public:
    int static convertDigitsArrayIntoNumber(char digits[], int length);
    static char* convertNumberIntoDigitsArray(int number);
};


#endif
